package com.senac.projetoFinal.repository;

import com.senac.projetoFinal.models.ItensReserva;
import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItensReservaRepository extends JpaRepository<ItensReserva, Long> {
    java.util.List<ItensReserva> findAllByReservaId(Long id);
}
