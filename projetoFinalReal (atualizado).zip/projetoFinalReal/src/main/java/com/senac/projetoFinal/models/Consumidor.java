package com.senac.projetoFinal.models;

import javax.persistence.Entity;

@Entity
public class Consumidor extends Pessoa {
}
