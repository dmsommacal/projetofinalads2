package com.senac.projetoFinal.repository;

import com.senac.projetoFinal.models.Consumidor;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ConsumidorRepository extends JpaRepository<Consumidor, Long> {
}
